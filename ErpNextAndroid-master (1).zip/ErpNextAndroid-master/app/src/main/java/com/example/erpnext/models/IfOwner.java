package com.example.erpnext.models;

public class IfOwner {
}
