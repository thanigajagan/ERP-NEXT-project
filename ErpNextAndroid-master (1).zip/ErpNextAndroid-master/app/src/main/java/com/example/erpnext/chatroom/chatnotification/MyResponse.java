package com.example.erpnext.chatroom.chatnotification;

public class MyResponse {

    public int success;
}
