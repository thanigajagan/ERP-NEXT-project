package com.example.erpnext.callbacks;


import com.example.erpnext.models.CheckOpeningEntry;

public interface CheckOPECallback {
    void onEntryClick(CheckOpeningEntry openingEntry);
}
