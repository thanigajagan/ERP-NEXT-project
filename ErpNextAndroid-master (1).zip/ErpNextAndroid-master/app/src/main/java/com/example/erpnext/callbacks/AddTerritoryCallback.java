package com.example.erpnext.callbacks;

import com.example.erpnext.models.Target;

public interface AddTerritoryCallback {
    void onDeleteTargetItem(Target target, int position);
}
