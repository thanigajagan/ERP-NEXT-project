package com.example.erpnext.callbacks;


import java.util.List;

public interface SearchItesmCallback {
    void onItemClick(List<String> list);

}
