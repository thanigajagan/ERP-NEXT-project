package com.example.erpnext.callbacks;


import com.example.erpnext.models.Item;

public interface ShortcutsCallback {
    void onShortcutClick(Item item);
}
