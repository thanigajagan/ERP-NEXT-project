package com.example.erpnext.callbacks;


import com.example.erpnext.models.SearchItemDetail;

public interface PurchaseItemCallback {

    void onDeleteClick(SearchItemDetail itemDetail);
}
