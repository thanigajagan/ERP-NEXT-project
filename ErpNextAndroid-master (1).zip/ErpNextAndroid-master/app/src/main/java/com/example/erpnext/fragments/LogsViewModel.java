package com.example.erpnext.fragments;

import androidx.lifecycle.ViewModel;

public class LogsViewModel extends ViewModel {

}
