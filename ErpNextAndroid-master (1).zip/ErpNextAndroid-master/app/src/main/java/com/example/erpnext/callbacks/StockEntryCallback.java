package com.example.erpnext.callbacks;

public interface StockEntryCallback {

    void onDeleteItemClick(int position);
}
