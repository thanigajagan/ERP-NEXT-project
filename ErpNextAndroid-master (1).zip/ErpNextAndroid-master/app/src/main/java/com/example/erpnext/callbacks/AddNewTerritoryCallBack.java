package com.example.erpnext.callbacks;


import com.example.erpnext.models.Target;

public interface AddNewTerritoryCallBack {


    void onDeleteTarget(Target target, int position);
}
