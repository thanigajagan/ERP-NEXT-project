package com.example.erpnext.callbacks;

public interface DateCallBack {
    void onSelect(String date);
}
