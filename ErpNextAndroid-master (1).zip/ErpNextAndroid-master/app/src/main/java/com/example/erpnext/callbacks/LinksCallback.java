package com.example.erpnext.callbacks;


import com.example.erpnext.models.Link;

public interface LinksCallback {
    void onLinkClick(Link link);
}
