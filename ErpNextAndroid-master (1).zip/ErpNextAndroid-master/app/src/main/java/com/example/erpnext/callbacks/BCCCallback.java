package com.example.erpnext.callbacks;

import com.example.erpnext.adapters.viewHolders.BCCViewHolder;

public interface BCCCallback {
    void onDeleteBCC(String item, BCCViewHolder viewHolder, int position);
}
